import "server-only";

import { createClient } from "@supabase/supabase-js";

export function adminDb() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Brakuje SUPABASE_SERVICE_ROLE_KEY albo NEXT_PUBLIC_SUPABASE_URL.");

  return createClient(url, key, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}
