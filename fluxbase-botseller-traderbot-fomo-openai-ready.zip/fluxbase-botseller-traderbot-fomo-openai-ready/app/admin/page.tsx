import AdminApp from "@/components/admin/AdminApp";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default function AdminPage() {
  return <AdminApp />;
}
