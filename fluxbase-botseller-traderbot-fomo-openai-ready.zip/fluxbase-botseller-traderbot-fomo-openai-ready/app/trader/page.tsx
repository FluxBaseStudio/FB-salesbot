import TraderApp from "@/components/trader/TraderApp";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default function TraderPage() {
  return <TraderApp />;
}
